import React from 'react';
import { Navbar,Nav} from 'react-bootstrap';
import Main from './components/main';
import { Link,NavLink} from 'react-router-dom';
import './App.css';




class App extends React.Component {
  render(){
    return(
      <div>
        <div className="main">
          <div >
            <Navbar className="nav-bar">
              <Navbar.Brand className="nav-bar-brand" as={Link} to='/'>Anastasia Papko</Navbar.Brand>
              <Nav className="nav-elements">
                <Nav.Link as={NavLink} to="/" exact>Home</Nav.Link>
                <Nav.Link as={NavLink} to="/inspiration">Inspiration</Nav.Link>
                <Nav.Link as={NavLink} to="/lifestyle">Lifestyle</Nav.Link>
                <Nav.Link as={NavLink} to="/travelling">Travelling</Nav.Link>
              </Nav>
            </Navbar>
          </div>
        </div>
        <div className="main-page">
          <Main/>

        </div>
      </div>
      
    );
  }
}

 
export default App;
