import React from 'react';
import Instafeed from '/instafeed.js/dist/instafeed.min.js';

class Inspiration extends React.Component{
    render(){
        return(
            <h1>This is an inspiration page</h1>
        );
    }
}

var userFeed = new Instafeed({
    get: 'user',
    userId: '8987997106',
    clientId: '924f677fa3854436947ab4372ffa688d',
    accessToken: '8987997106.924f677.8555ecbd52584f41b9b22ec1a16dafb9',
    resolution: 'standard_resolution',
    template: '<a href="{{link}}" target="_blank" id="{{id}}"><img src="{{image}}" /></a>',
    sortBy: 'most-recent',
    limit: 4,
    links: false
  });
  userFeed.run();

export default Inspiration;