import React from 'react';
import {Carousel} from 'react-bootstrap';
import './mainpage.css';

class MainPage extends React.Component{
    render(){
        return(
           <div >
                <div className="images">
                    <Carousel className="carousel">
                        <Carousel.Item className="carousel-item">
                            <img
                            className="slide-img1"
                            src="/images/slide3.jpg"
                            alt="First slide"
                            />
                            <Carousel.Caption>
                            <h3>Inspiration</h3>
                            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                            </Carousel.Caption>
                        </Carousel.Item>
                        <Carousel.Item className="carousel-item">
                            <img
                            className="slide-img2"
                            src="/images/slide2.jpg"
                            alt="Third slide"
                            />

                            <Carousel.Caption>
                            <h3>Lifestyle</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                            </Carousel.Caption>
                        </Carousel.Item>
                        <Carousel.Item className="carousel-item">
                            <img
                            className="slide-img3"
                            src="/images/slide1.jpg"
                            alt="Third slide"
                            />

                            <Carousel.Caption>
                            <h3>Travelling</h3>
                            <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
                            </Carousel.Caption>
                        </Carousel.Item>
                    </Carousel>
                        
                </div>
                <div className="social-media-links" >
                    <a href="https://www.facebook.com/profile.php?id=100008173802094" class="fa fa-facebook"></a>
                    <a href="http://www.instagram.com/anasta.sia.p" class="fa fa-instagram"></a>
                
                </div>

           </div>
        );
    }
}

export default MainPage;