import React from 'react';

class Travelling extends React.Component{
    render(){
        return(
            <h1>This is travelling page</h1>
        );
    }
}

export default Travelling;