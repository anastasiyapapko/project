import React from 'react';

class Lifestyle extends React.Component{
    render(){
        return(
            <h1>This is lifestyle page</h1>
        );
    }
}

export default Lifestyle;